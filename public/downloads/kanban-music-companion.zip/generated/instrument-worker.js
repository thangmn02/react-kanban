import * as e from "../vendor/ort.wasm.min.mjs";
//#region \0rolldown/runtime.js
var t = Object.create, n = Object.defineProperty, r = Object.getOwnPropertyDescriptor, i = Object.getOwnPropertyNames, a = Object.getPrototypeOf, o = Object.prototype.hasOwnProperty, s = (e, t) => () => (t || (e((t = { exports: {} }).exports, t), e = null), t.exports), c = (e, t, a, s) => {
	if (t && typeof t == "object" || typeof t == "function") for (var c = i(t), l = 0, u = c.length, d; l < u; l++) d = c[l], !o.call(e, d) && d !== a && n(e, d, {
		get: ((e) => t[e]).bind(null, d),
		enumerable: !(s = r(t, d)) || s.enumerable
	});
	return e;
}, l = /* @__PURE__ */ ((e, r, i) => (i = e == null ? {} : t(a(e)), c(r || !e || !e.__esModule || !o.call(e, "default") ? n(i, "default", {
	value: e,
	enumerable: !0
}) : i, e)))((/* @__PURE__ */ s(((e, t) => {
	function n(e) {
		if (this.size = e | 0, this.size <= 1 || this.size & this.size - 1) throw Error("FFT size must be a power of two and bigger than 1");
		this._csize = e << 1;
		for (var t = Array(this.size * 2), n = 0; n < t.length; n += 2) {
			let e = Math.PI * n / this.size;
			t[n] = Math.cos(e), t[n + 1] = -Math.sin(e);
		}
		this.table = t;
		for (var r = 0, i = 1; this.size > i; i <<= 1) r++;
		this._width = r % 2 == 0 ? r - 1 : r, this._bitrev = Array(1 << this._width);
		for (var a = 0; a < this._bitrev.length; a++) {
			this._bitrev[a] = 0;
			for (var o = 0; o < this._width; o += 2) {
				var s = this._width - o - 2;
				this._bitrev[a] |= (a >>> o & 3) << s;
			}
		}
		this._out = null, this._data = null, this._inv = 0;
	}
	t.exports = n, n.prototype.fromComplexArray = function(e, t) {
		for (var n = t || Array(e.length >>> 1), r = 0; r < e.length; r += 2) n[r >>> 1] = e[r];
		return n;
	}, n.prototype.createComplexArray = function() {
		let e = Array(this._csize);
		for (var t = 0; t < e.length; t++) e[t] = 0;
		return e;
	}, n.prototype.toComplexArray = function(e, t) {
		for (var n = t || this.createComplexArray(), r = 0; r < n.length; r += 2) n[r] = e[r >>> 1], n[r + 1] = 0;
		return n;
	}, n.prototype.completeSpectrum = function(e) {
		for (var t = this._csize, n = t >>> 1, r = 2; r < n; r += 2) e[t - r] = e[r], e[t - r + 1] = -e[r + 1];
	}, n.prototype.transform = function(e, t) {
		if (e === t) throw Error("Input and output buffers must be different");
		this._out = e, this._data = t, this._inv = 0, this._transform4(), this._out = null, this._data = null;
	}, n.prototype.realTransform = function(e, t) {
		if (e === t) throw Error("Input and output buffers must be different");
		this._out = e, this._data = t, this._inv = 0, this._realTransform4(), this._out = null, this._data = null;
	}, n.prototype.inverseTransform = function(e, t) {
		if (e === t) throw Error("Input and output buffers must be different");
		this._out = e, this._data = t, this._inv = 1, this._transform4();
		for (var n = 0; n < e.length; n++) e[n] /= this.size;
		this._out = null, this._data = null;
	}, n.prototype._transform4 = function() {
		var e = this._out, t = this._csize, n = 1 << this._width, r = t / n << 1, i, a, o = this._bitrev;
		if (r === 4) for (i = 0, a = 0; i < t; i += r, a++) {
			let e = o[a];
			this._singleTransform2(i, e, n);
		}
		else for (i = 0, a = 0; i < t; i += r, a++) {
			let e = o[a];
			this._singleTransform4(i, e, n);
		}
		var s = this._inv ? -1 : 1, c = this.table;
		for (n >>= 2; n >= 2; n >>= 2) {
			r = t / n << 1;
			var l = r >>> 2;
			for (i = 0; i < t; i += r) for (var u = i + l, d = i, f = 0; d < u; d += 2, f += n) {
				let t = d, n = t + l, r = n + l, i = r + l, a = e[t], o = e[t + 1], u = e[n], p = e[n + 1], m = e[r], h = e[r + 1], g = e[i], _ = e[i + 1], v = a, y = o, b = c[f], x = s * c[f + 1], S = u * b - p * x, C = u * x + p * b, w = c[2 * f], T = s * c[2 * f + 1], E = m * w - h * T, D = m * T + h * w, O = c[3 * f], k = s * c[3 * f + 1], A = g * O - _ * k, j = g * k + _ * O, M = v + E, N = y + D, P = v - E, F = y - D, I = S + A, L = C + j, R = s * (S - A), z = s * (C - j), B = M + I, V = N + L, H = M - I, U = N - L, W = P + z, G = F - R, K = P - z, q = F + R;
				e[t] = B, e[t + 1] = V, e[n] = W, e[n + 1] = G, e[r] = H, e[r + 1] = U, e[i] = K, e[i + 1] = q;
			}
		}
	}, n.prototype._singleTransform2 = function(e, t, n) {
		let r = this._out, i = this._data, a = i[t], o = i[t + 1], s = i[t + n], c = i[t + n + 1], l = a + s, u = o + c, d = a - s, f = o - c;
		r[e] = l, r[e + 1] = u, r[e + 2] = d, r[e + 3] = f;
	}, n.prototype._singleTransform4 = function(e, t, n) {
		let r = this._out, i = this._data, a = this._inv ? -1 : 1, o = n * 2, s = n * 3, c = i[t], l = i[t + 1], u = i[t + n], d = i[t + n + 1], f = i[t + o], p = i[t + o + 1], m = i[t + s], h = i[t + s + 1], g = c + f, _ = l + p, v = c - f, y = l - p, b = u + m, x = d + h, S = a * (u - m), C = a * (d - h), w = g + b, T = _ + x, E = v + C, D = y - S, O = g - b, k = _ - x, A = v - C, j = y + S;
		r[e] = w, r[e + 1] = T, r[e + 2] = E, r[e + 3] = D, r[e + 4] = O, r[e + 5] = k, r[e + 6] = A, r[e + 7] = j;
	}, n.prototype._realTransform4 = function() {
		var e = this._out, t = this._csize, n = 1 << this._width, r = t / n << 1, i, a, o = this._bitrev;
		if (r === 4) for (i = 0, a = 0; i < t; i += r, a++) {
			let e = o[a];
			this._singleRealTransform2(i, e >>> 1, n >>> 1);
		}
		else for (i = 0, a = 0; i < t; i += r, a++) {
			let e = o[a];
			this._singleRealTransform4(i, e >>> 1, n >>> 1);
		}
		var s = this._inv ? -1 : 1, c = this.table;
		for (n >>= 2; n >= 2; n >>= 2) {
			r = t / n << 1;
			var l = r >>> 1, u = l >>> 1, d = u >>> 1;
			for (i = 0; i < t; i += r) for (var f = 0, p = 0; f <= d; f += 2, p += n) {
				var m = i + f, h = m + u, g = h + u, _ = g + u, v = e[m], y = e[m + 1], b = e[h], x = e[h + 1], S = e[g], C = e[g + 1], w = e[_], T = e[_ + 1], E = v, D = y, O = c[p], k = s * c[p + 1], A = b * O - x * k, j = b * k + x * O, M = c[2 * p], N = s * c[2 * p + 1], P = S * M - C * N, F = S * N + C * M, I = c[3 * p], L = s * c[3 * p + 1], R = w * I - T * L, z = w * L + T * I, B = E + P, V = D + F, H = E - P, U = D - F, W = A + R, G = j + z, K = s * (A - R), q = s * (j - z), J = B + W, Y = V + G, X = H + q, Z = U - K;
				if (e[m] = J, e[m + 1] = Y, e[h] = X, e[h + 1] = Z, f === 0) {
					var ee = B - W, te = V - G;
					e[g] = ee, e[g + 1] = te;
					continue;
				}
				if (f !== d) {
					var ne = H, re = -U, ie = B, ae = -V, oe = -s * q, se = -s * K, ce = -s * G, le = -s * W, ue = ne + oe, de = re + se, fe = ie + le, pe = ae - ce, Q = i + u - f, $ = i + l - f;
					e[Q] = ue, e[Q + 1] = de, e[$] = fe, e[$ + 1] = pe;
				}
			}
		}
	}, n.prototype._singleRealTransform2 = function(e, t, n) {
		let r = this._out, i = this._data, a = i[t], o = i[t + n], s = a + o, c = a - o;
		r[e] = s, r[e + 1] = 0, r[e + 2] = c, r[e + 3] = 0;
	}, n.prototype._singleRealTransform4 = function(e, t, n) {
		let r = this._out, i = this._data, a = this._inv ? -1 : 1, o = n * 2, s = n * 3, c = i[t], l = i[t + n], u = i[t + o], d = i[t + s], f = c + u, p = c - u, m = l + d, h = a * (l - d), g = f + m, _ = p, v = -h, y = f - m, b = p, x = h;
		r[e] = g, r[e + 1] = 0, r[e + 2] = _, r[e + 3] = v, r[e + 4] = y, r[e + 5] = 0, r[e + 6] = b, r[e + 7] = x;
	};
})))(), 1), u = "87c5b6d2874aeb8377b3dca27c9223aa252a6cdb", d = "kora-instrument-spleeter-v1", f = 44100, p = 1024, m = [
	{
		name: "vocals",
		bytes: 39361004,
		sha256: "341bd47da8a0ea590178e9d342cbd6ac168cf05f0bf8ce6a62d1ef18f8358701"
	},
	{
		name: "drums",
		bytes: 39361003,
		sha256: "fe832ff1b9ea54b7d3fd8256fa464e21dbccb3cafa83d4f72d3ee2d5dc21f997"
	},
	{
		name: "bass",
		bytes: 39361002,
		sha256: "be84af108ec6a5b538d35fd5643799393c4c0bbfa21f2ea1308ca1364a076d81"
	},
	{
		name: "other",
		bytes: 39361003,
		sha256: "9fa7fc4ecbe8d75f0b3c9fea65a0c8b7a32518a7c0ed55339036ad342fb8bedd"
	}
].map((e) => ({
	...e,
	url: `https://huggingface.co/Best-Practice/spleeter-4stems-onnx/resolve/${u}/${e.name}.onnx`
}));
async function h(e, { cache: t, fetcher: n = fetch, digest: r = crypto.subtle.digest.bind(crypto.subtle), progress: i = () => {} } = {}) {
	let a = async (t) => t.byteLength === e.bytes && [...new Uint8Array(await r("SHA-256", t))].map((e) => e.toString(16).padStart(2, "0")).join("") === e.sha256, o = await t?.match(e.url);
	if (o) {
		let n = await o.arrayBuffer();
		if (await a(n)) return i(e.bytes), new Uint8Array(n);
		await t.delete(e.url);
	}
	let s = await n(e.url, {
		credentials: "omit",
		referrerPolicy: "no-referrer",
		signal: AbortSignal.timeout(12e4)
	});
	if (!s.ok || !s.body) throw Error("Model download unavailable");
	let c = s.body.getReader(), l = new Uint8Array(e.bytes), u = 0;
	try {
		for (;;) {
			let { value: e, done: t } = await c.read();
			if (t) break;
			if (u + e.length > l.length) throw Error("Unexpected model size");
			l.set(e, u), u += e.length, i(u);
		}
	} finally {
		await c.cancel().catch(() => {});
	}
	if (!await a(l)) throw Error("Model integrity check failed");
	return await t?.put(e.url, new Response(l, { headers: { "Content-Type": "application/octet-stream" } })), l;
}
//#endregion
//#region extensions/kanban-music/model-window.js
function g(e, t) {
	let n = 0, r = 0;
	for (; t < e.length && r < 35;) {
		let i = e[t++];
		if (n += (i & 127) * 2 ** r, !(i & 128)) return {
			value: n,
			at: t
		};
		r += 7;
	}
	throw Error("Invalid model protobuf");
}
function _(e) {
	let t = [];
	do {
		let n = e % 128;
		e = Math.floor(e / 128), t.push(n | (e ? 128 : 0));
	} while (e);
	return Uint8Array.from(t);
}
function v(e) {
	let t = [], n = 0;
	for (; n < e.length;) {
		let r = n, i = g(e, n);
		n = i.at;
		let a = i.value & 7, o = Math.floor(i.value / 8), s = n, c;
		if (a === 2) {
			let t = g(e, n);
			s = t.at, c = s + t.value;
		} else if (a === 0) c = g(e, n).at;
		else if (a === 1) c = n + 8;
		else if (a === 5) c = n + 4;
		else throw Error("Unsupported model protobuf");
		if (c > e.length) throw Error("Truncated model");
		t.push({
			number: o,
			wire: a,
			start: r,
			payload: s,
			end: c
		}), n = c;
	}
	return t;
}
function y(e) {
	let t = new Uint8Array(e.reduce((e, t) => e + t.length, 0)), n = 0;
	for (let r of e) t.set(r, n), n += r.length;
	return t;
}
function b(e, t, n) {
	return y([
		e.subarray(t.start, t.payload - _(t.end - t.payload).length),
		_(n.length),
		n
	]);
}
function x(e, t) {
	let n = [
		2,
		1,
		2
	], r = (e, i) => {
		let a = [], o = 0, s = 0;
		for (let c of v(e)) if (i < n.length && c.number === n[i]) {
			let t = r(e.subarray(c.payload, c.end), i + 1);
			a.push(b(e, c, t)), s++;
		} else if (i === n.length && c.number === 1 && o++ === 2) {
			let n = e.subarray(c.payload, c.end), r = v(n).find((e) => e.number === 1 && e.wire === 0);
			if (!r || g(n, r.payload).value !== 512) throw Error("Unexpected model time shape");
			a.push(b(e, c, y([
				n.subarray(0, r.payload),
				_(t),
				n.subarray(r.end)
			]))), s++;
		} else a.push(e.subarray(c.start, c.end));
		if (s !== 1) throw Error("Unexpected model tensor");
		return y(a);
	};
	return r(e, 0);
}
function S(e, t = 128) {
	if (![
		64,
		128,
		256,
		512
	].includes(t)) throw Error("Invalid model window");
	let n = 0, r = v(e).map((r) => {
		if (r.number !== 7) return e.subarray(r.start, r.end);
		n++;
		let i = e.subarray(r.payload, r.end), a = 0, o = v(i).flatMap((e) => e.number === 13 ? [] : e.number !== 11 && e.number !== 12 ? [i.subarray(e.start, e.end)] : (a++, [b(i, e, x(i.subarray(e.payload, e.end), t))]));
		if (a !== 2) throw Error("Unexpected model graph");
		return b(e, r, y(o));
	});
	if (n !== 1) throw Error("Unexpected model");
	return y(r);
}
//#endregion
//#region extensions/kanban-music/instrument-note-tracker.js
var C = 44100 / 4096, w = (e, t) => e.reduce((e, n, r) => e + n * t[r], 0) / Math.max(1e-9, Math.hypot(...e) * Math.hypot(...t)), T = class {
	constructor() {
		this.note = 0, this.active = !1, this.lastNoteAt = -Infinity, this.lastAttackEnergy = 0, this.lastSeen = -Infinity, this.lastPublish = -Infinity, this.previousEnergy = 0, this.profile = null, this.pitch = null, this.candidatePitch = null, this.candidateFrames = 0;
	}
	analyze(e, t, n = 1) {
		let r = [], i = 0;
		for (let t = 10; t < 700; t++) i += e[t] ** 2;
		for (let t = 45; t <= 96; t++) {
			let n = 440 * 2 ** ((t - 69) / 12), i = [];
			for (let t = 1; t <= 6; t++) {
				let r = Math.round(n * t / C);
				i.push(r < e.length - 1 ? Math.max(e[r - 1], e[r], e[r + 1]) : 0);
			}
			let a = i[0], o = i.reduce((e, t, n) => e + t / (n + 1), 0);
			if (a < o * .18) continue;
			let s = this.profile ? w(i, this.profile) : 1;
			r.push({
				midi: t,
				harmonics: i,
				score: o,
				similarity: s
			});
		}
		r.sort((e, t) => t.score - e.score);
		let a = r[0], o = t - this.lastSeen < 80 ? r.find((e) => e.midi === this.pitch && e.similarity >= .8 && e.score >= (a?.score || 0) * .85) : null, s = this.profile && t - this.lastSeen < 600 ? r.find((e) => e.similarity >= .88 && e.score >= (a?.score || 0) * .6) : null, c = o || s || a, l = c?.score || 0, u = c && l >= .3 && i > .002 && l ** 2 > i * .035 && n >= .12, d = !1;
		if (u && (!this.profile || t - this.lastSeen >= 600 || c.similarity >= .8)) {
			this.candidatePitch === c.midi ? this.candidateFrames++ : (this.candidatePitch = c.midi, this.candidateFrames = 1);
			let e = this.candidateFrames >= 2 && this.pitch !== c.midi, n = l > Math.max(.02, this.previousEnergy * 1.45), r = e && t - this.lastNoteAt < 100 && l > this.lastAttackEnergy * 4;
			r && (this.pitch = c.midi), !r && this.candidateFrames >= 2 && t - this.lastNoteAt >= 55 && (e || n || !this.active) && (this.note++, this.lastNoteAt = t, this.lastAttackEnergy = l, d = !0, this.pitch = c.midi), this.active = !0, this.lastSeen = t;
			let i = Math.max(1e-8, Math.hypot(...c.harmonics)), a = c.harmonics.map((e) => e / i);
			this.profile = this.profile && c.similarity >= .8 ? a.map((e, t) => this.profile[t] * .9 + e * .1) : a;
		} else t - this.lastSeen >= 80 && (this.active = !1, this.candidateFrames = 0, this.candidatePitch = null);
		let f = d || t - this.lastPublish >= 90 || !this.active && this.wasActive;
		return this.wasActive = this.active, this.previousEnergy = u ? l : 0, f ? (this.lastPublish = t, {
			active: this.active,
			level: this.active ? Math.min(1, l / 30) : 0,
			note: this.note
		}) : null;
	}
};
e.env.wasm.numThreads = 1, e.env.wasm.wasmPaths = new URL(
	/* @vite-ignore */
	"../vendor/",
	import.meta.url
).href;
var E = 1024, D = 4096, O = 64, k = 32, A = f * 8, j = [new Float32Array(A), new Float32Array(A)], M = new l.default(D), N = M.createComplexArray(), P = Float32Array.from({ length: D }, (e, t) => .5 - .5 * Math.cos(2 * Math.PI * t / D)), F = new Float32Array(D), I = new T(), L, R, z, B = 0, V = 0, H = !1, U = !1, W = (e) => self.postMessage(e);
function G(e) {
	U || (U = !0, W({
		kind: "error",
		message: String(e?.message || "Instrument analysis failed").slice(0, 160)
	}));
}
async function K() {
	let t = await caches.open(d);
	L = [];
	let n = 0, r = m.reduce((e, t) => e + t.bytes, 0);
	for (let i of m) {
		let a = await h(i, {
			cache: t,
			progress: (e) => W({
				kind: "progress",
				bytes: n + e,
				total: r
			})
		}), o = await e.InferenceSession.create(S(a, 128), { executionProviders: ["wasm"] });
		L.push(o), n += i.bytes;
	}
	let i = new e.Tensor("float32", new Float32Array(256 * p), [
		2,
		1,
		128,
		p
	]);
	for (let e of L) (await e.run({ x: i })).y.dispose();
	i.dispose(), W({ kind: "ready" });
}
async function q() {
	if (!(H || U || !L || z === void 0)) {
		H = !0;
		try {
			for (; B >= (V + O + k - 1) * E + D / 2;) {
				if (B - Math.max(0, (V - k) * E - D / 2) >= A) throw Error("Instrument analysis cannot keep up");
				let t = new Float32Array(256 * p);
				for (let e = 0; e < 2; e++) for (let n = 0; n < 128; n++) {
					let r = (V + n - k) * E - D / 2;
					for (let t = 0; t < D; t++) {
						let n = r + t;
						F[t] = (n < 0 ? 0 : j[e][n % A]) * P[t];
					}
					M.realTransform(N, F);
					let i = (e * 128 + n) * p;
					for (let e = 0; e < p; e++) t[i + e] = Math.hypot(N[e * 2], N[e * 2 + 1]);
				}
				let n = new e.Tensor("float32", t, [
					2,
					1,
					128,
					p
				]), r = [];
				try {
					for (let e of L) r.push((await e.run({ x: n })).y);
					let e = [], i = new Float32Array(128 * p), a = /* @__PURE__ */ new Float64Array(128), o = /* @__PURE__ */ new Float64Array(128), s = /* @__PURE__ */ new Float64Array(128);
					for (let e = 16; e < 112; e++) {
						let n = 0, c = 0, l = 0;
						for (let a = 0; a < p; a++) {
							let o = 0;
							for (let i = 0; i < 2; i++) {
								let s = (i * 128 + e) * p + a, u = 1e-10;
								for (let e of r) u += e.data[s] ** 2;
								let d = r[3].data[s] ** 2 / u;
								if (!Number.isFinite(d)) throw Error("Invalid model output");
								let f = t[s] * d, m = t[s] * r[2].data[s] ** 2 / u;
								c += m * m, n += f * f, l += t[s] ** 2, o += d >= .55 ? f : 0;
							}
							i[e * p + a] = o * .5;
						}
						a[e] = c, o[e] = n, s[e] = l;
					}
					for (let t = k; t < 96; t++) {
						let n = 0, r = 0;
						for (let e = -16; e <= 16; e++) {
							let i = 1 - Math.abs(e) / 17;
							n += a[t + e] * i, r += o[t + e] * i;
						}
						let c = (z + (V + t - k) * E) / f, l = I.analyze(i.subarray(t * p, (t + 1) * p), c * 1e3, n > r * 1.5 ? 0 : o[t] / Math.max(1e-10, s[t]));
						l && e.push({
							time: c,
							state: l
						});
					}
					W({
						kind: "notes",
						events: e
					}), V += O;
				} finally {
					n.dispose(), r.forEach((e) => e.dispose());
				}
			}
		} catch (e) {
			G(e);
		} finally {
			H = !1;
		}
	}
}
self.onmessage = ({ data: e }) => {
	if (e?.kind === "prepare") {
		R ||= K().catch(G);
		return;
	}
	if (e?.kind !== "pcm" || U || !L) return;
	let { left: t, right: n, startFrame: r } = e;
	if (!(t instanceof Float32Array) || !(n instanceof Float32Array) || t.length !== n.length || t.length > 4096 || !Number.isSafeInteger(r)) {
		G(/* @__PURE__ */ Error("Invalid captured audio"));
		return;
	}
	z ??= r;
	let i = r - z - B;
	if (i < 0 || i > 2048) {
		G(/* @__PURE__ */ Error("Captured audio discontinuity"));
		return;
	}
	for (let e = 0; e < i; e++) j[0][B % A] = 0, j[1][B % A] = 0, B++;
	for (let e = 0; e < t.length; e++) j[0][B % A] = t[e], j[1][B % A] = n[e], B++;
	W({ kind: "ack" }), q();
};
//#endregion
